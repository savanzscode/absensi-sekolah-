A Pen created at CodePen.io. You can find this one at http://codepen.io/mblode/pen/gGIAm.

 Based off of Nate Wiley's "Styled Radio Buttons" pen. 
Similar concept but with a flat design.
Play around with color variables ($red, $blue, $green) to adjust the colors of the buttons.