tinymce.addI18n('en',{
    'Formula': 'Formula editor',
    'Cancel': 'Cancel',
    'Insert Formula': 'Insert formula'
});
